<?php
defined('ABSPATH') || exit;
global $up_user;
?>

